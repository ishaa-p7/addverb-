package com.telusko.springdatarestdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataRestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
